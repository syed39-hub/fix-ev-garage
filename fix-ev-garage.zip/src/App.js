import React from 'react';

export default function App() {
  return <div className="text-center mt-20 text-3xl font-bold">Fix EV Garage</div>;
}