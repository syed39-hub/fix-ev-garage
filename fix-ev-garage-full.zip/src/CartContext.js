import React, { createContext, useContext, useState, useEffect } from 'react';
const CartContext = createContext();
export function useCart(){ return useContext(CartContext); }
export function CartProvider({children}){
  const [items,setItems] = useState(()=>{ try{ const r=localStorage.getItem('fixev_cart'); return r?JSON.parse(r):[] }catch(e){return[] }});
  useEffect(()=>localStorage.setItem('fixev_cart',JSON.stringify(items)),[items]);
  const add=(p,qty=1)=> setItems(cur=>{ const found = cur.find(i=>i.id===p.id); if(found) return cur.map(i=> i.id===p.id?{...i,qty:i.qty+qty}:i); return [...cur,{...p,qty}]});
  const remove=(id)=> setItems(cur=>cur.filter(i=>i.id!==id));
  const updateQty=(id,qty)=> setItems(cur=>cur.map(i=> i.id===id?{...i,qty}:i));
  const clear=()=>setItems([]);
  const subtotal = items.reduce((s,it)=>s+it.price*it.qty,0);
  return <CartContext.Provider value={{items,add,remove,updateQty,clear,subtotal}}>{children}</CartContext.Provider>
}
