import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import Logo from './Logo';
import { useCart } from '../CartContext';
function NavLink({to,children}){ const loc = useLocation(); const active = loc.pathname.startsWith(to); return <Link to={to} className={`px-3 py-2 rounded text-sm ${active? 'bg-slate-900 text-white':'text-slate-700 hover:bg-slate-50'}`}>{children}</Link> }
export default function TopNav(){
  const {items} = useCart();
  const cartCount = items.reduce((s,i)=>s+i.qty,0);
  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3"><Logo /></Link>
        <nav className="hidden md:flex gap-4 items-center">
          <NavLink to="/services">Services</NavLink>
          <NavLink to="/vfd">Industrial VFD</NavLink>
          <NavLink to="/parts">Parts & Tools</NavLink>
          <NavLink to="/training">Training</NavLink>
          <NavLink to="/contact">Contact</NavLink>
        </nav>
        <div className="flex items-center gap-3">
          <div className="text-sm text-slate-600 hidden sm:block">+91 98765 43210</div>
          <Link to="/cart" className="relative inline-flex items-center gap-2 px-3 py-2 border rounded-lg">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 6h15l-1.5 9h-12L4 3H2" stroke="#0f172a" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
            <span className="text-sm">Cart</span>
            {cartCount>0 && <span className="absolute -top-2 -right-2 bg-amber-400 text-xs text-slate-900 px-2 rounded-full">{cartCount}</span>}
          </Link>
        </div>
      </div>
    </header>
  )
}
