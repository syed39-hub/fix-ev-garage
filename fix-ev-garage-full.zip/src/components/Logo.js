import React from 'react';
export default function Logo(){ return (
  <div className="flex items-center gap-3">
    <svg width="44" height="44" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="1" y="6" width="16" height="12" rx="2" stroke="var(--dark)" strokeWidth="1.2" />
      <path d="M5 6V4a3 3 0 0 1 6 0v2" stroke="var(--dark)" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M18 10v6" stroke="var(--dark)" strokeWidth="1.6" strokeLinecap="round" />
      <circle cx="18" cy="8" r="2" stroke="var(--dark)" strokeWidth="1.2" />
    </svg>
    <div className="flex flex-col">
      <span className="font-bold text-slate-900">Fix EV Garage</span>
      <span className="text-xs -mt-1 text-slate-500">EV • ECU • BCM • VFD • Training</span>
    </div>
  </div>
) }
