import React from 'react';
export default function Footer(){
  return (
    <footer className="bg-slate-900 text-slate-200 py-8 mt-12">
      <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row justify-between gap-6">
        <div>
          <div className="font-bold text-xl">Fix EV Garage</div>
          <div className="text-sm mt-2 text-slate-300">EV & Module repair • VFD service • Parts • Training</div>
        </div>
        <div className="text-sm text-slate-300">
          <div>© {new Date().getFullYear()} Fix EV Garage</div>
          <div className="mt-2">Terms • Privacy • Warranty info</div>
        </div>
      </div>
    </footer>
  )
}
