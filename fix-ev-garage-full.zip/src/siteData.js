export const COMPANY = {
  name: 'Fix EV Garage',
  tagline: 'EV • ECU • BCM • VFD • Training',
  email: 'service@fixevgarage.example',
  phone: '+91 98765 43210',
  address: '123 Tech Lane, Industrial Estate, YourCity'
};

export const services = [
  { id: 'ev-repair', title: 'EV Car Repair', description: 'High-voltage battery diagnosis, motor/inverter repair, charging & BMS troubleshooting, software updates and ECU flashing.' },
  { id: 'module-repair', title: 'ECM / BCM & Module Repair', description: 'Board-level diagnostics and repair for vehicle controllers, solder/BGA-level fixes, connector repair and firmware recovery.' },
  { id: 'aux-modules', title: 'Chargers & Converters', description: 'Charger repairs, DC–DC converter troubleshooting, CAN bus simulation and bench testing.' }
];

export const vfdService = {
  title: 'Industrial VFD Repair',
  bullets: ['Power stage & IGBT replacement','Control board fault repair','Encoder & feedback loop testing','Parameter recovery, backup & onsite support']
};

export const products = [
  { id: 'p1', title: 'Refurbished ECM', price: 6500, sku: 'ECM-RF-01', stock: 4 },
  { id: 'p2', title: 'VFD 2.2kW (3ph)', price: 24500, sku: 'VFD-2K2', stock: 7 },
  { id: 'p3', title: 'OBD-II Advanced Scanner', price: 12800, sku: 'SCAN-ADV', stock: 12 },
  { id: 'p4', title: 'HV Connector Kit', price: 1450, sku: 'HV-KIT', stock: 25 }
];

export const trainingCourses = [
  { id: 't1', title: 'EV Fundamentals', length: '2 days', price: 6000 },
  { id: 't2', title: 'Module Repair & Diagnostics', length: '3 days', price: 12500 },
  { id: 't3', title: 'Industrial VFD Repair', length: '2 days', price: 9000 }
];

export const formatINR = (n)=>`₹${Number(n).toLocaleString('en-IN')}`;
