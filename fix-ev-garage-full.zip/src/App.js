import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { CartProvider } from './CartContext';
import TopNav from './components/TopNav';
import Footer from './components/Footer';
import Home from './pages/Home';
import ServicesPage from './pages/ServicesPage';
import VFDPage from './pages/VFDPage';
import PartsPage from './pages/PartsPage';
import ProductDetail from './pages/ProductDetail';
import TrainingPage from './pages/TrainingPage';
import TrainingDetail from './pages/TrainingDetail';
import ContactPage from './pages/ContactPage';
import CartPage from './pages/CartPage';
import CheckoutPage from './pages/CheckoutPage';

export default function App(){
  return (
    <Router basename="/fix-ev-garage">
      <CartProvider>
        <TopNav />
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/services" element={<ServicesPage/>} />
          <Route path="/vfd" element={<VFDPage/>} />
          <Route path="/parts" element={<PartsPage/>} />
          <Route path="/parts/:id" element={<ProductDetail/>} />
          <Route path="/training" element={<TrainingPage/>} />
          <Route path="/training/:id" element={<TrainingDetail/>} />
          <Route path="/contact" element={<ContactPage/>} />
          <Route path="/cart" element={<CartPage/>} />
          <Route path="/checkout" element={<CheckoutPage/>} />
        </Routes>
        <Footer />
      </CartProvider>
    </Router>
  )
}
